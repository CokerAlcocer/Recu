package com.example.alcocerduran_u2rec

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONObject

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val edtNombre = findViewById<EditText>(R.id.edtNombre)
        val edtDesc = findViewById<EditText>(R.id.edtDesc)
        val spEstado = findViewById<Spinner>(R.id.spEstado)
        val edtLat = findViewById<EditText>(R.id.edtLat)
        val edtLng = findViewById<EditText>(R.id.edtLng)
        val btnCancelar = findViewById<Button>(R.id.btnGuardar)
        val btnGuardar = findViewById<Button>(R.id.btnGuardar)

        var queue = Volley.newRequestQueue(this@MainActivity3)
        var urlSP = "https://utez-appdesign-u2.herokuapp.com/state"

        val listenerSP = Response.Listener<JSONArray> { response ->
            var datos = mutableListOf<String>()

            for(i in 0 until response.length()){
                var nombre = response.getJSONObject(i).getString("name")

                datos.add(nombre)
            }

            val adaptador = ArrayAdapter(this@MainActivity3, android.R.layout.simple_list_item_1, datos)
            spEstado.adapter = adaptador
        }

        val errorSP = Response.ErrorListener { error -> Log.e("ERROR", error.toString()) }

        val peticionSP = JsonArrayRequest(Request.Method.GET, urlSP, null, listenerSP, errorSP)
        queue.add(peticionSP)

        //PETICION POST
        val cola = Volley.newRequestQueue(this@MainActivity3)
        val url = "https://utez-appdesign-u2.herokuapp.com/place"
        val error = Response.ErrorListener { error ->
            Toast.makeText(this@MainActivity3, "Error de registro", Toast.LENGTH_LONG).show()
        }
        val listener = Response.Listener<JSONObject> { response ->
            if("insertId" in response.names().toString() && response.getInt("insertId") != 0){
                Toast.makeText(this@MainActivity3, "Registro exitoso", Toast.LENGTH_LONG).show()
                edtNombre.setText("")
                edtDesc.setText("")
                edtLat.setText("")
                edtLng.setText("")
                spEstado.setSelection(0)
            }else{
                Toast.makeText(this@MainActivity3, "Error de registro", Toast.LENGTH_LONG).show()
            }
        }

        btnCancelar.setOnClickListener(){
            finish()
        }

        btnGuardar.setOnClickListener(){

            var nombre = edtNombre.text.toString()
            var desc = edtDesc.text.toString()
            var op = spEstado.selectedItem.toString()
            var estado = ""
            when(op){
                "Morelos" ->{
                    estado = "5"
                }
                "Guerrero" ->{
                    estado = "15"
                }
                "Veracruz" ->{
                    estado = "25"
                }
                "Michoacán" ->{
                    estado = "35"
                }
                "Puebla" ->{
                    estado = "45"
                }
                "San Luis Potosí" ->{
                    estado = "55"
                }
            }
            Log.e("Valor", estado)
            var lat = edtLat.text.toString()
            var lng = edtLng.text.toString()

            if(nombre != "" && desc != "" && estado != "" && lat != "" && lng != ""){
                val body = JSONObject()
                body.put("title", nombre)
                body.put("description", desc)
                body.put("stateNo", estado)
                body.put("lat", lat)
                body.put("lon", lng)

                val peticion = JsonObjectRequest(Request.Method.POST, url, body, listener, error)
                cola.add(peticion)

            }else{
                Toast.makeText(this@MainActivity3, "Los campos no pueden estar vacios", Toast.LENGTH_LONG).show()
            }

        }
    }
}