package com.example.alcocerduran_u2rec

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView

class CustomAdapter(val ctxt : Context, val layout : Int, val data : List<Lugar>): BaseAdapter() {

    val inflater = ctxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(position: Int): Any {
        return data[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertedView: View?, parent: ViewGroup?): View {
        val view = inflater.inflate(layout, parent, false)

        val nombre = view.findViewById<TextView>(R.id.txtNombre)
        val desc = view.findViewById<TextView>(R.id.txtDesc)
        val estado = view.findViewById<Button>(R.id.btnLetra)

        val lugar = getItem(position) as Lugar

        nombre.text = lugar.nombre
        desc.text = lugar.desc

        when(lugar.estado){
            5 ->{
                estado.text = "M"
            }
            15 ->{
                estado.text = "G"
            }
            25 ->{
                estado.text = "V"
            }
            35 ->{
                estado.text = "Mi"
            }
            45 ->{
                estado.text = "P"
            }
            55 ->{
                estado.text = "S"
            }
        }

        return view
    }

}