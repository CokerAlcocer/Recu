package com.example.alcocerduran_u2rec

data class Lugar(val id : Int,
                 val nombre : String,
                 val desc : String,
                 val estado : Int,
                 val lat : Double,
                 val lng : Double) {
}