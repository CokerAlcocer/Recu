package com.example.alcocerduran_u2rec

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val lvLista = findViewById<ListView>(R.id.lvLista)

        var queue = Volley.newRequestQueue(this@MainActivity)
        var url = "https://utez-appdesign-u2.herokuapp.com/place"

        val listener = Response.Listener<JSONArray> { response ->
            var datos = mutableListOf<Lugar>()

            for(i in 0 until response.length()){
                var id = response.getJSONObject(i).getInt("placeNo")
                var nombre = response.getJSONObject(i).getString("name")
                var desc = response.getJSONObject(i).getString("description")
                var state = response.getJSONObject(i).getInt("stateNo")
                var lat = response.getJSONObject(i).getDouble("lat")
                var lon = response.getJSONObject(i).getDouble("lon")

                datos.add(Lugar(id, nombre, desc, state, lat, lon))
            }

            val adaptador = CustomAdapter(this@MainActivity, R.layout.activity_main2, datos)
            lvLista.adapter = adaptador
        }

        val error = Response.ErrorListener { error -> Log.e("ERROR", error.toString()) }

        val peticion = JsonArrayRequest(Request.Method.GET, url, null, listener, error)
        queue.add(peticion)

        lvLista.setOnItemClickListener { parent, view, position, id ->
            val builder = AlertDialog.Builder(this@MainActivity)
            builder.setTitle("Confirmación de borrado")
            builder.setMessage("Estas seguro de borrar el evento?")
            builder.setPositiveButton("Si") { dialog, button ->
                val lugar = parent.adapter.getItem(position) as Lugar
                val url_borrado = "${url}/${lugar.id.toString()}"

                val listener = Response.Listener<JSONObject> {
                    Toast.makeText(this@MainActivity, "Registro borrado", Toast.LENGTH_SHORT).show()
                }
                val peticion = JsonObjectRequest(Request.Method.DELETE, url_borrado, null, listener,error)
                queue.add(peticion)
            }
            builder.setNegativeButton("No") { dialog, button ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    // Añadir funcionalidad al menú
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.mnuSalir -> finish()
            R.id.mnuNuevo -> {
                // Debe de abrir el formulario de captura
                val intent = Intent(this@MainActivity, MainActivity3::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}